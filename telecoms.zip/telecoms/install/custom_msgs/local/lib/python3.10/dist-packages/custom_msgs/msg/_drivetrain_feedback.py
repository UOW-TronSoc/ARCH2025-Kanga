# generated from rosidl_generator_py/resource/_idl.py.em
# with input from custom_msgs:msg/DrivetrainFeedback.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import math  # noqa: E402, I100

# Member 'wheel_position'
# Member 'wheel_velocity'
# Member 'wheel_torque'
import numpy  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_DrivetrainFeedback(type):
    """Metaclass of message 'DrivetrainFeedback'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('custom_msgs')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'custom_msgs.msg.DrivetrainFeedback')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__drivetrain_feedback
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__drivetrain_feedback
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__drivetrain_feedback
            cls._TYPE_SUPPORT = module.type_support_msg__msg__drivetrain_feedback
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__drivetrain_feedback

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class DrivetrainFeedback(metaclass=Metaclass_DrivetrainFeedback):
    """Message class 'DrivetrainFeedback'."""

    __slots__ = [
        '_epoch_time',
        '_wheel_position',
        '_wheel_velocity',
        '_wheel_torque',
    ]

    _fields_and_field_types = {
        'epoch_time': 'int64',
        'wheel_position': 'float[4]',
        'wheel_velocity': 'float[4]',
        'wheel_torque': 'float[4]',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('int64'),  # noqa: E501
        rosidl_parser.definition.Array(rosidl_parser.definition.BasicType('float'), 4),  # noqa: E501
        rosidl_parser.definition.Array(rosidl_parser.definition.BasicType('float'), 4),  # noqa: E501
        rosidl_parser.definition.Array(rosidl_parser.definition.BasicType('float'), 4),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.epoch_time = kwargs.get('epoch_time', int())
        if 'wheel_position' not in kwargs:
            self.wheel_position = numpy.zeros(4, dtype=numpy.float32)
        else:
            self.wheel_position = numpy.array(kwargs.get('wheel_position'), dtype=numpy.float32)
            assert self.wheel_position.shape == (4, )
        if 'wheel_velocity' not in kwargs:
            self.wheel_velocity = numpy.zeros(4, dtype=numpy.float32)
        else:
            self.wheel_velocity = numpy.array(kwargs.get('wheel_velocity'), dtype=numpy.float32)
            assert self.wheel_velocity.shape == (4, )
        if 'wheel_torque' not in kwargs:
            self.wheel_torque = numpy.zeros(4, dtype=numpy.float32)
        else:
            self.wheel_torque = numpy.array(kwargs.get('wheel_torque'), dtype=numpy.float32)
            assert self.wheel_torque.shape == (4, )

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.epoch_time != other.epoch_time:
            return False
        if all(self.wheel_position != other.wheel_position):
            return False
        if all(self.wheel_velocity != other.wheel_velocity):
            return False
        if all(self.wheel_torque != other.wheel_torque):
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def epoch_time(self):
        """Message field 'epoch_time'."""
        return self._epoch_time

    @epoch_time.setter
    def epoch_time(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'epoch_time' field must be of type 'int'"
            assert value >= -9223372036854775808 and value < 9223372036854775808, \
                "The 'epoch_time' field must be an integer in [-9223372036854775808, 9223372036854775807]"
        self._epoch_time = value

    @builtins.property
    def wheel_position(self):
        """Message field 'wheel_position'."""
        return self._wheel_position

    @wheel_position.setter
    def wheel_position(self, value):
        if isinstance(value, numpy.ndarray):
            assert value.dtype == numpy.float32, \
                "The 'wheel_position' numpy.ndarray() must have the dtype of 'numpy.float32'"
            assert value.size == 4, \
                "The 'wheel_position' numpy.ndarray() must have a size of 4"
            self._wheel_position = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 len(value) == 4 and
                 all(isinstance(v, float) for v in value) and
                 all(not (val < -3.402823466e+38 or val > 3.402823466e+38) or math.isinf(val) for val in value)), \
                "The 'wheel_position' field must be a set or sequence with length 4 and each value of type 'float' and each float in [-340282346600000016151267322115014000640.000000, 340282346600000016151267322115014000640.000000]"
        self._wheel_position = numpy.array(value, dtype=numpy.float32)

    @builtins.property
    def wheel_velocity(self):
        """Message field 'wheel_velocity'."""
        return self._wheel_velocity

    @wheel_velocity.setter
    def wheel_velocity(self, value):
        if isinstance(value, numpy.ndarray):
            assert value.dtype == numpy.float32, \
                "The 'wheel_velocity' numpy.ndarray() must have the dtype of 'numpy.float32'"
            assert value.size == 4, \
                "The 'wheel_velocity' numpy.ndarray() must have a size of 4"
            self._wheel_velocity = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 len(value) == 4 and
                 all(isinstance(v, float) for v in value) and
                 all(not (val < -3.402823466e+38 or val > 3.402823466e+38) or math.isinf(val) for val in value)), \
                "The 'wheel_velocity' field must be a set or sequence with length 4 and each value of type 'float' and each float in [-340282346600000016151267322115014000640.000000, 340282346600000016151267322115014000640.000000]"
        self._wheel_velocity = numpy.array(value, dtype=numpy.float32)

    @builtins.property
    def wheel_torque(self):
        """Message field 'wheel_torque'."""
        return self._wheel_torque

    @wheel_torque.setter
    def wheel_torque(self, value):
        if isinstance(value, numpy.ndarray):
            assert value.dtype == numpy.float32, \
                "The 'wheel_torque' numpy.ndarray() must have the dtype of 'numpy.float32'"
            assert value.size == 4, \
                "The 'wheel_torque' numpy.ndarray() must have a size of 4"
            self._wheel_torque = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 len(value) == 4 and
                 all(isinstance(v, float) for v in value) and
                 all(not (val < -3.402823466e+38 or val > 3.402823466e+38) or math.isinf(val) for val in value)), \
                "The 'wheel_torque' field must be a set or sequence with length 4 and each value of type 'float' and each float in [-340282346600000016151267322115014000640.000000, 340282346600000016151267322115014000640.000000]"
        self._wheel_torque = numpy.array(value, dtype=numpy.float32)
