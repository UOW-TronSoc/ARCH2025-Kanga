# generated from rosidl_generator_py/resource/_idl.py.em
# with input from custom_msgs:msg/DrivetrainControl.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_DrivetrainControl(type):
    """Metaclass of message 'DrivetrainControl'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('custom_msgs')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'custom_msgs.msg.DrivetrainControl')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__drivetrain_control
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__drivetrain_control
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__drivetrain_control
            cls._TYPE_SUPPORT = module.type_support_msg__msg__drivetrain_control
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__drivetrain_control

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class DrivetrainControl(metaclass=Metaclass_DrivetrainControl):
    """Message class 'DrivetrainControl'."""

    __slots__ = [
        '_epoch_time',
        '_lf_drive',
        '_lb_drive',
        '_rb_drive',
        '_rf_drive',
    ]

    _fields_and_field_types = {
        'epoch_time': 'int64',
        'lf_drive': 'int8',
        'lb_drive': 'int8',
        'rb_drive': 'int8',
        'rf_drive': 'int8',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('int64'),  # noqa: E501
        rosidl_parser.definition.BasicType('int8'),  # noqa: E501
        rosidl_parser.definition.BasicType('int8'),  # noqa: E501
        rosidl_parser.definition.BasicType('int8'),  # noqa: E501
        rosidl_parser.definition.BasicType('int8'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.epoch_time = kwargs.get('epoch_time', int())
        self.lf_drive = kwargs.get('lf_drive', int())
        self.lb_drive = kwargs.get('lb_drive', int())
        self.rb_drive = kwargs.get('rb_drive', int())
        self.rf_drive = kwargs.get('rf_drive', int())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.epoch_time != other.epoch_time:
            return False
        if self.lf_drive != other.lf_drive:
            return False
        if self.lb_drive != other.lb_drive:
            return False
        if self.rb_drive != other.rb_drive:
            return False
        if self.rf_drive != other.rf_drive:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def epoch_time(self):
        """Message field 'epoch_time'."""
        return self._epoch_time

    @epoch_time.setter
    def epoch_time(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'epoch_time' field must be of type 'int'"
            assert value >= -9223372036854775808 and value < 9223372036854775808, \
                "The 'epoch_time' field must be an integer in [-9223372036854775808, 9223372036854775807]"
        self._epoch_time = value

    @builtins.property
    def lf_drive(self):
        """Message field 'lf_drive'."""
        return self._lf_drive

    @lf_drive.setter
    def lf_drive(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'lf_drive' field must be of type 'int'"
            assert value >= -128 and value < 128, \
                "The 'lf_drive' field must be an integer in [-128, 127]"
        self._lf_drive = value

    @builtins.property
    def lb_drive(self):
        """Message field 'lb_drive'."""
        return self._lb_drive

    @lb_drive.setter
    def lb_drive(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'lb_drive' field must be of type 'int'"
            assert value >= -128 and value < 128, \
                "The 'lb_drive' field must be an integer in [-128, 127]"
        self._lb_drive = value

    @builtins.property
    def rb_drive(self):
        """Message field 'rb_drive'."""
        return self._rb_drive

    @rb_drive.setter
    def rb_drive(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'rb_drive' field must be of type 'int'"
            assert value >= -128 and value < 128, \
                "The 'rb_drive' field must be an integer in [-128, 127]"
        self._rb_drive = value

    @builtins.property
    def rf_drive(self):
        """Message field 'rf_drive'."""
        return self._rf_drive

    @rf_drive.setter
    def rf_drive(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'rf_drive' field must be of type 'int'"
            assert value >= -128 and value < 128, \
                "The 'rf_drive' field must be an integer in [-128, 127]"
        self._rf_drive = value
