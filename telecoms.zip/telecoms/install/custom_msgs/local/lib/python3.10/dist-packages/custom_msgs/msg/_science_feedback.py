# generated from rosidl_generator_py/resource/_idl.py.em
# with input from custom_msgs:msg/ScienceFeedback.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import math  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_ScienceFeedback(type):
    """Metaclass of message 'ScienceFeedback'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('custom_msgs')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'custom_msgs.msg.ScienceFeedback')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__science_feedback
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__science_feedback
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__science_feedback
            cls._TYPE_SUPPORT = module.type_support_msg__msg__science_feedback
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__science_feedback

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class ScienceFeedback(metaclass=Metaclass_ScienceFeedback):
    """Message class 'ScienceFeedback'."""

    __slots__ = [
        '_water_percent',
        '_temperature',
        '_ilmenite_percent',
    ]

    _fields_and_field_types = {
        'water_percent': 'float',
        'temperature': 'float',
        'ilmenite_percent': 'float',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.water_percent = kwargs.get('water_percent', float())
        self.temperature = kwargs.get('temperature', float())
        self.ilmenite_percent = kwargs.get('ilmenite_percent', float())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.water_percent != other.water_percent:
            return False
        if self.temperature != other.temperature:
            return False
        if self.ilmenite_percent != other.ilmenite_percent:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def water_percent(self):
        """Message field 'water_percent'."""
        return self._water_percent

    @water_percent.setter
    def water_percent(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'water_percent' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'water_percent' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._water_percent = value

    @builtins.property
    def temperature(self):
        """Message field 'temperature'."""
        return self._temperature

    @temperature.setter
    def temperature(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'temperature' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'temperature' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._temperature = value

    @builtins.property
    def ilmenite_percent(self):
        """Message field 'ilmenite_percent'."""
        return self._ilmenite_percent

    @ilmenite_percent.setter
    def ilmenite_percent(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'ilmenite_percent' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'ilmenite_percent' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._ilmenite_percent = value
