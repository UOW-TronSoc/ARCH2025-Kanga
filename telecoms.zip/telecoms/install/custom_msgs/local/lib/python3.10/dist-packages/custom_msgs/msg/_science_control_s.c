// generated from rosidl_generator_py/resource/_idl_support.c.em
// with input from custom_msgs:msg/ScienceControl.idl
// generated code does not contain a copyright notice
#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
#include <Python.h>
#include <stdbool.h>
#ifndef _WIN32
# pragma GCC diagnostic push
# pragma GCC diagnostic ignored "-Wunused-function"
#endif
#include "numpy/ndarrayobject.h"
#ifndef _WIN32
# pragma GCC diagnostic pop
#endif
#include "rosidl_runtime_c/visibility_control.h"
#include "custom_msgs/msg/detail/science_control__struct.h"
#include "custom_msgs/msg/detail/science_control__functions.h"


ROSIDL_GENERATOR_C_EXPORT
bool custom_msgs__msg__science_control__convert_from_py(PyObject * _pymsg, void * _ros_message)
{
  // check that the passed message is of the expected Python class
  {
    char full_classname_dest[48];
    {
      char * class_name = NULL;
      char * module_name = NULL;
      {
        PyObject * class_attr = PyObject_GetAttrString(_pymsg, "__class__");
        if (class_attr) {
          PyObject * name_attr = PyObject_GetAttrString(class_attr, "__name__");
          if (name_attr) {
            class_name = (char *)PyUnicode_1BYTE_DATA(name_attr);
            Py_DECREF(name_attr);
          }
          PyObject * module_attr = PyObject_GetAttrString(class_attr, "__module__");
          if (module_attr) {
            module_name = (char *)PyUnicode_1BYTE_DATA(module_attr);
            Py_DECREF(module_attr);
          }
          Py_DECREF(class_attr);
        }
      }
      if (!class_name || !module_name) {
        return false;
      }
      snprintf(full_classname_dest, sizeof(full_classname_dest), "%s.%s", module_name, class_name);
    }
    assert(strncmp("custom_msgs.msg._science_control.ScienceControl", full_classname_dest, 47) == 0);
  }
  custom_msgs__msg__ScienceControl * ros_message = _ros_message;
  {  // heat_status
    PyObject * field = PyObject_GetAttrString(_pymsg, "heat_status");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->heat_status = (Py_True == field);
    Py_DECREF(field);
  }
  {  // water_status
    PyObject * field = PyObject_GetAttrString(_pymsg, "water_status");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->water_status = (Py_True == field);
    Py_DECREF(field);
  }
  {  // ilmenite_status
    PyObject * field = PyObject_GetAttrString(_pymsg, "ilmenite_status");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->ilmenite_status = (Py_True == field);
    Py_DECREF(field);
  }
  {  // deploy_heat
    PyObject * field = PyObject_GetAttrString(_pymsg, "deploy_heat");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->deploy_heat = (Py_True == field);
    Py_DECREF(field);
  }
  {  // deploy_sensors
    PyObject * field = PyObject_GetAttrString(_pymsg, "deploy_sensors");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->deploy_sensors = (Py_True == field);
    Py_DECREF(field);
  }

  return true;
}

ROSIDL_GENERATOR_C_EXPORT
PyObject * custom_msgs__msg__science_control__convert_to_py(void * raw_ros_message)
{
  /* NOTE(esteve): Call constructor of ScienceControl */
  PyObject * _pymessage = NULL;
  {
    PyObject * pymessage_module = PyImport_ImportModule("custom_msgs.msg._science_control");
    assert(pymessage_module);
    PyObject * pymessage_class = PyObject_GetAttrString(pymessage_module, "ScienceControl");
    assert(pymessage_class);
    Py_DECREF(pymessage_module);
    _pymessage = PyObject_CallObject(pymessage_class, NULL);
    Py_DECREF(pymessage_class);
    if (!_pymessage) {
      return NULL;
    }
  }
  custom_msgs__msg__ScienceControl * ros_message = (custom_msgs__msg__ScienceControl *)raw_ros_message;
  {  // heat_status
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->heat_status ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "heat_status", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // water_status
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->water_status ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "water_status", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // ilmenite_status
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->ilmenite_status ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "ilmenite_status", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // deploy_heat
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->deploy_heat ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "deploy_heat", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // deploy_sensors
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->deploy_sensors ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "deploy_sensors", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }

  // ownership of _pymessage is transferred to the caller
  return _pymessage;
}
