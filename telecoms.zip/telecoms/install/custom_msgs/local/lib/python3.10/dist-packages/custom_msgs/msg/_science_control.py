# generated from rosidl_generator_py/resource/_idl.py.em
# with input from custom_msgs:msg/ScienceControl.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_ScienceControl(type):
    """Metaclass of message 'ScienceControl'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('custom_msgs')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'custom_msgs.msg.ScienceControl')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__science_control
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__science_control
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__science_control
            cls._TYPE_SUPPORT = module.type_support_msg__msg__science_control
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__science_control

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class ScienceControl(metaclass=Metaclass_ScienceControl):
    """Message class 'ScienceControl'."""

    __slots__ = [
        '_heat_status',
        '_water_status',
        '_ilmenite_status',
        '_deploy_heat',
        '_deploy_sensors',
    ]

    _fields_and_field_types = {
        'heat_status': 'boolean',
        'water_status': 'boolean',
        'ilmenite_status': 'boolean',
        'deploy_heat': 'boolean',
        'deploy_sensors': 'boolean',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.heat_status = kwargs.get('heat_status', bool())
        self.water_status = kwargs.get('water_status', bool())
        self.ilmenite_status = kwargs.get('ilmenite_status', bool())
        self.deploy_heat = kwargs.get('deploy_heat', bool())
        self.deploy_sensors = kwargs.get('deploy_sensors', bool())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.heat_status != other.heat_status:
            return False
        if self.water_status != other.water_status:
            return False
        if self.ilmenite_status != other.ilmenite_status:
            return False
        if self.deploy_heat != other.deploy_heat:
            return False
        if self.deploy_sensors != other.deploy_sensors:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def heat_status(self):
        """Message field 'heat_status'."""
        return self._heat_status

    @heat_status.setter
    def heat_status(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'heat_status' field must be of type 'bool'"
        self._heat_status = value

    @builtins.property
    def water_status(self):
        """Message field 'water_status'."""
        return self._water_status

    @water_status.setter
    def water_status(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'water_status' field must be of type 'bool'"
        self._water_status = value

    @builtins.property
    def ilmenite_status(self):
        """Message field 'ilmenite_status'."""
        return self._ilmenite_status

    @ilmenite_status.setter
    def ilmenite_status(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'ilmenite_status' field must be of type 'bool'"
        self._ilmenite_status = value

    @builtins.property
    def deploy_heat(self):
        """Message field 'deploy_heat'."""
        return self._deploy_heat

    @deploy_heat.setter
    def deploy_heat(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'deploy_heat' field must be of type 'bool'"
        self._deploy_heat = value

    @builtins.property
    def deploy_sensors(self):
        """Message field 'deploy_sensors'."""
        return self._deploy_sensors

    @deploy_sensors.setter
    def deploy_sensors(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'deploy_sensors' field must be of type 'bool'"
        self._deploy_sensors = value
