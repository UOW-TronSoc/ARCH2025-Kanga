import os
from glob import glob
from setuptools import find_packages, setup

package_name = 'rtabmap_testing'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob(os.path.join('launch', '*launch.[pxy][yma]*'))),
        ('share/rtabmap_testing/urdf', ['urdf/box.urdf']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='tronsoc',
    maintainer_email='mechatronics-society@uow.edu.au',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
        ],
    },
)
